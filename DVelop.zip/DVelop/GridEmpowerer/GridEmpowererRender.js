﻿function WWP_GridEmpowerer() {
    this.show = function() {
        var t, n;
        this.eventsAttached || (this.eventsAttached = !0, t = this, gx.fx.obs.addObserver("gx.onafterevent", window, function(n) {
            return function() {
                n.onaftereventx()
            }
        }(this)), gx.fx.obs.addObserver("gx.onload", window, function(n) {
            return function() {
                n.onaftereventx()
            }
        }(this)), gx.fx.obs.addObserver("grid.onafterrender", window, function(n) {
            return function() {
                n.onaftereventx()
            }
        }(this)), gx.fx.obs.addObserver("webcom.all_rendered", window, function(n) {
            return function() {
                n.onaftereventx()
            }
        }(this)), this.resizeHandler = function() {
            this.HandleWindowResize()
        }.closure(this), gx.evt.attach(window, "resize", this.resizeHandler), this.loadHandler = function() {
            this.HandleWindowLoad()
        }.closure(this), gx.evt.attach(window, "load", this.loadHandler));
        n = WWP_GetGrid(this);
        n.data("WWP.Empowerer") == null && n.data("WWP.Empowerer", this);
        this.Empower()
    };
    this.destroy = function() {
        this.resizeHandler != null && gx.evt.detach(window, "resize", this.resizeHandler);
        this.loadHandler != null && gx.evt.detach(window, "load", this.loadHandler);
        this.timerT != null && (clearInterval(this.timerT), this.timerT = null)
    };
    this.HandleWindowResize = function() {
        var n = WWP_GetGrid(this),
            t;
        this.IsReadyToEmpower(n) && (t = n.find(">table"), this.Empowered && (this.ColumnsOrHeaderFixer != null && this.ColumnsOrHeaderFixer.Refresh(), this.InfiniteScrolling == "Grid" && t.find(">tbody").hasClass("gx-infinite-scrolling-element") && this.InfiniteScrolling_FinishedProcessing()))
    };
    this.HandleWindowLoad = function() {
        this.Empower()
    };
    this.onaftereventx = function() {
        this.Empower()
    };
    this.IsReadyToEmpower = function(n) {
        var r, t, i;
        if ((n == null && (n = WWP_GetGrid(this)), this.HasCategories && (this.CategoriesHelper = n.data("WWP.GridTitlesCategories"), this.CategoriesHelper == null)) || this.HasTitleSettings && (this.TitleSettingsHelper = n.data("WWP.TitleSettings"), this.TitleSettingsHelper == null) || this.HasColumnsSelector && wwp.settings.columnsSelector.AllowColumnReordering && (this.ColumnSelectorHelper = n.data("WWP.GridColumnSelector"), this.ColumnSelectorHelper == null) || this.HasRowGroups && (this.RowGroupsHelper = n.data("WWP.RowGroupsHelper"), this.RowGroupsHelper == null)) return !1;
        if (this.PopoversInGrid != "" && this.PopoversInGrid != null)
            for (r = this.PopoversInGrid.split("|"), t = 0; t < r.length; t += 1)
                if (i = "WWP." + r[t].toUpperCase(), this[i] = n.data(i), this[i] == null) return !1;
        return WWP_Debug_Log(!1, "ReadyToEmpower"), !0
    };
    this.Empower = function() {
        var r = WWP_GetGrid(this),
            u, i, n, t, f;
        if (this.IsReadyToEmpower(r)) {
            if (r.parent().addClass("GridParentCell"), this.TitleSettingsHelper != null && this.TitleSettingsHelper.updateGrid(), SetMinWidthTotalizers(), this.CategoriesHelper != null && this.CategoriesHelper.updateGridTitlesCategories(!1), this.RowGroupsHelper != null && this.RowGroupsHelper.ProcessGroup(!1), this.PopoversInGrid != "" && this.PopoversInGrid != null)
                for (u = this.PopoversInGrid.split("|"), i = 0; i < u.length; i += 1) this["WWP." + u[i].toUpperCase()].InitGridPopovers();
            this.ColumnSelectorHelper != null ? this.UpdateColumnsOrder() : this.FixedColumns != "" && this.UpdateFixedColumns();
            this.CategoriesHelper != null && this.CategoriesHelper.mergeTitlesCategoryCells();
            this.RowGroupsHelper != null && this.RowGroupsHelper.mergeGroupRowCellsAndAddTitle();
            this.ColumnSelectorHelper != null && wwp.settings.columnsSelector.AllowColumnReordering && wwp.settings.columnsSelector.AllowColumnDragging && this.AllowReOrderDraggingColumns();
            ApplyBootstrapSelect();
            this.FreezeColumnsOrHeader();
            this.InfiniteScrolling != "False" && (n = r.find(">table"), n.data("IS_ProcessedRecords", n.find(">tbody").children().length), this.InfiniteScrolling == "Grid" && (n.find(">tbody").hasClass("gx-infinite-scrolling-element") ? this.InfiniteScrolling_FinishedProcessing() : this.timerT == null && (t = this, f = 200, this.timerT = setInterval(function() {
                n.find(">tbody").hasClass("gx-infinite-scrolling-element") ? t.InfiniteScrolling_FinishedProcessing() : (f--, f < 0 && t.timerT != null && (clearInterval(t.timerT), t.timerT = null))
            }, 10))));
            this.Empowered = !0
        }
    };
    this.InfiniteScrolling_FinishedProcessing = function() {
        this.timerT != null && (clearInterval(this.timerT), this.timerT = null);
        var n = WWP_GetGrid(this),
            t = n.find(">table>thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)"),
            i = n.find(">table>tfoot>tr:not(.FGFootRow)");
        n.find(">table>tbody>tr:not(.DVGroupByRow,.FGRowLine):eq(0)>*").each(function() {
            var r = $(this).index(),
                n = $(this).css("width");
            i.find(">*:eq(" + r + ")").css({
                "min-width": n,
                "max-width": n
            });
            t.find(">*:eq(" + r + ")").css({
                "min-width": n,
                "max-width": n
            })
        })
    };
    this.UpdateFixedColumns = function() {
        for (var t = WWP_GetGrid(this).find(">table").find(">thead>tr:last-child()"), i = this.FixedColumns.split(";"), r = t.children().length, n = 0; n < r; n += 1) i[n] != "" && t.find(">th:eq(" + n + ")").addClass("ConfigFixedColumn FixedColumn" + i[n])
    };
    this.UpdateColumnsOrder = function() {
        var i, s, h, y, p, w, c, r, u, n, l, o, t;
        if (this.ColumnSelectorHelper.DropDownOptionsData_Columns != null && this.ColumnSelectorHelper.DropDownOptionsData_Columns.length > 0)
            if (i = WWP_GetGrid(this).find(">table"), i.data("ColumnsOrder") == null) {
                if (!i.is(":visible") && i.find(">tbody>tr").length == 0 && (s = i.attr("id") + "", s.indexOf("GridContainerTbl") != -1 && (h = $("#" + s.replace("GridContainerTbl", "GridinsertlineContainerTbl")), h.length == 1 && (i = h, i.data("ColumnsOrder") != null)))) return;
                var r = i.find(">thead>tr:last-child()>th"),
                    e = -1,
                    f = this.FixedColumns.split(";"),
                    a = 0,
                    v = 0;
                for (n = 0; n < r.length; n += 1) n < f.length && (f[n] == "L" || f[n] == "R") && ($(r[n]).data("fixed", f[n]), f[n] == "L" ? a++ : v++), ($(r[n]).hasClass("EditableGridAuxCol") && $(r[n - 1]).hasClass("DisableColMoving") || $(r[n]).find(">span>input[name=selectAllCheckbox]").length == 1) && $(r[n]).addClass("DisableColMoving"), $(r[n]).is(".DisableColMoving,.EditableGridAuxCol") || ($(r[n]).find(">*").length > 0 && $(r[n]).hasClass("WWColumn") ? (e++, $(r[n]).data("colIndex", e)) : $(r[n]).addClass("DisableColMoving")), (this.InfiniteScrolling != "False" || wwp.settings.columnsSelector.AllowColumnResizing) && $(r[n]).data("origColIndex", n);
                if (e <= this.ColumnSelectorHelper.DropDownOptionsData_Columns.length - 1) {
                    for (y = this.UpdateColumnsOrder_FixedColumns(i, r, !0, a), p = this.UpdateColumnsOrder_FixedColumns(i, i.find(">thead>tr:last-child()>th"), !1, v), i.data("ColumnsOrder", ""), this.ColumnSelectorHelper.TotalizersCalled = null, n = y; n < this.ColumnSelectorHelper.DropDownOptionsData_Columns.length - p; n += 1)
                        for (w = Math.min.apply(Math, this.ColumnSelectorHelper.DropDownOptionsData_Columns.map(function(n) {
                                return !n.found && !n.fixed ? n.O : 9999
                            })), t = 0; t < this.ColumnSelectorHelper.DropDownOptionsData_Columns.length; t += 1)
                            if (this.ColumnSelectorHelper.DropDownOptionsData_Columns[t].O == w && !this.ColumnSelectorHelper.DropDownOptionsData_Columns[t].found) {
                                this.ColumnSelectorHelper.DropDownOptionsData_Columns[t].O = n;
                                this.ColumnSelectorHelper.DropDownOptionsData_Columns[t].found = !0;
                                this.ColumnSelectorHelper.DropDownOptionsData_Columns[t].freezable = this.UpdateColumnsOrder_IsColumnFreezable(t, i);
                                break
                            } for (n = 0; n < this.ColumnSelectorHelper.DropDownOptionsData_Columns.length; n += 1)
                        for (delete this.ColumnSelectorHelper.DropDownOptionsData_Columns[n].found, t = 0; t < this.ColumnSelectorHelper.DropDownOptionsData_Columns.length; t += 1)
                            if (this.ColumnSelectorHelper.DropDownOptionsData_Columns[t].O == n) {
                                this.ReOrderColumn(i, t, n);
                                break
                            }
                } else console.log(f+'&'+r+'&'+a+'&'+v+'&'+" ERROR currentColIndex (" + e + ") != this.DropDownOptionsData_Columns.length - 1 (" + (this.ColumnSelectorHelper.DropDownOptionsData_Columns.length - 1) + ")");
                this.DropDownOptionsData_Columns = this.ColumnSelectorHelper.DropDownOptionsData_Columns
            } else if (this.InfiniteScrolling != "False" && (c = i.data("IS_ProcessedRecords"), c != i.find(">tbody").children().length)) {
            for (r = i.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)").last().find("th"), u = [], n = 0; n < r.length; n += 1) u.push(n);
            for (n = 0; n < r.length; n += 1)
                if (l = $(r[n]).data("origColIndex"), o = u[l], n != o) {
                    for (i.find(">tbody>tr:gt(" + (c - 1) + ")").each(function() {
                            $(this).find(">*:eq(" + o + ")").insertBefore($(this).find(">*:eq(" + n + ")"))
                        }), t = 0; t < r.length; t++) u[t] >= n && u[t] < o && u[t]++;
                    u[l] = n
                }
        }
    };
    this.UpdateColumnsOrder_IsColumnFreezable = function(n, t) {
        var i = !1,
            r;
        return this.TitleSettingsHelper != null && (r = this, t.find(">thead>tr:last-child()>th").each(function() {
            if ($(this).data("colIndex") == n) return i = r.TitleSettingsHelper.ColumnIsFreezable(this), !1
        })), i
    };
    this.UpdateColumnsOrder_FixedColumns = function(n, t, i, r) {
        for (var s = 0, e = i ? 0 : t.length - 1, h, c, a, l, o, f, u; e >= 0 && e <= t.length - 1 && $(t[e]).hasClass("DisableColMoving");) e += i ? 1 : -1;
        if (h = i ? "L" : "R", c = this, r > 0)
            for (o = 0; o < t.length; o += 1)
                if (f = i ? o : t.length - 1 - o, a = $(t[f]).data("fixed"), a == h && (u = $(t[f]).data("colIndex"), u != null && (this.ColumnSelectorHelper.DropDownOptionsData_Columns[u].O = i ? s : this.ColumnSelectorHelper.DropDownOptionsData_Columns.length - s - 1, i ? this.ColumnSelectorHelper.DropDownOptionsData_Columns[u].configFixedL = !0 : this.ColumnSelectorHelper.DropDownOptionsData_Columns[u].configFixedR = !0, this.ColumnSelectorHelper.DropDownOptionsData_Columns[u].found = !0, s++), n.find(">thead>tr:last-child()>th:eq(" + f + ")").addClass("ConfigFixedColumn FixedColumn" + h), (i && f > e || !i && f < e) && (n.find(">tbody>tr,>thead>tr,>tfoot>tr").each(function() {
                        c.UpdateColumnsOrder_FixedColumns_insert($(this).find(">*:eq(" + f + ")"), $(this).find(">*:eq(" + e + ")"), i)
                    }), $(t[f + 1]).hasClass("EditableGridAuxCol") && (n.find(">tbody>tr,>thead>tr,>tfoot>tr").each(function() {
                        c.UpdateColumnsOrder_FixedColumns_insert($(this).find(">*:eq(" + (f + (i ? 1 : 0)) + ")"), $(this).find(">*:eq(" + (e + (i ? 1 : 0)) + ")"), i)
                    }), e += i ? 1 : -1), e += i ? 1 : -1), r--, r == 0)) break;
        for (;;) {
            if (l = i ? Math.min.apply(Math, this.ColumnSelectorHelper.DropDownOptionsData_Columns.map(function(n) {
                    return !n.found && n.F == h ? n.O : 9999
                })) : Math.max.apply(Math, this.ColumnSelectorHelper.DropDownOptionsData_Columns.map(function(n) {
                    return !n.found && n.F == h ? n.O : -1
                })), l == (i ? 9999 : -1)) break;
            for (t = n.find(">thead>tr:last-child()>th"), o = 0; o < t.length; o += 1)
                if (f = i ? o : t.length - 1 - o, u = $(t[f]).data("colIndex"), u != null && !this.ColumnSelectorHelper.DropDownOptionsData_Columns[u].found && this.ColumnSelectorHelper.DropDownOptionsData_Columns[u].F == h && this.ColumnSelectorHelper.DropDownOptionsData_Columns[u].O == l) {
                    this.ColumnSelectorHelper.DropDownOptionsData_Columns[u].O = i ? s : this.ColumnSelectorHelper.DropDownOptionsData_Columns.length - s - 1;
                    i ? this.ColumnSelectorHelper.DropDownOptionsData_Columns[u].fixedL = !0 : this.ColumnSelectorHelper.DropDownOptionsData_Columns[u].fixedR = !0;
                    this.ColumnSelectorHelper.DropDownOptionsData_Columns[u].found = !0;
                    this.ColumnSelectorHelper.DropDownOptionsData_Columns[u].freezable = !0;
                    s++;
                    n.find(">thead>tr:last-child()>th:eq(" + f + ")").addClass("FixedColumn" + h);
                    n.find(">tbody>tr,>thead>tr,>tfoot>tr").each(function() {
                        c.UpdateColumnsOrder_FixedColumns_insert($(this).find(">*:eq(" + f + ")"), $(this).find(">*:eq(" + e + ")"), i)
                    });
                    $(t[f + 1]).hasClass("EditableGridAuxCol") && (n.find(">tbody>tr,>thead>tr,>tfoot>tr").each(function() {
                        c.UpdateColumnsOrder_FixedColumns_insert($(this).find(">*:eq(" + (f + (i ? 1 : 0)) + ")"), $(this).find(">*:eq(" + (e + (i ? 1 : 0)) + ")"), i)
                    }), e += i ? 1 : -1);
                    e += i ? 1 : -1;
                    break
                }
        }
        return s
    };
    this.UpdateColumnsOrder_FixedColumns_insert = function(n, t, i) {
        i ? n.insertBefore(t) : n.insertAfter(t)
    };
    this.AllowReOrderDraggingColumns = function() {
        var r = WWP_GetGrid(this).find(">table");
        if (r.data("ColumnsOrder") != null && r.data("ColumnsDragging") == null) {
            r.data("ColumnsDragging", "");
            var i = null,
                n = null,
                u = -1,
                t = this;
            r.find(">thead>tr>th:not(.DisableColMoving,.ConfigFixedColumn)").each(function() {
                $(this).addClass("WWPDraggable");
                this.draggable = !0;
                $(this).unbind("dragstart").bind("dragstart", function(r) {
                    r.stopPropagation();
                    n = $(this);
                    u = n.index();
                    n.addClass("WWPDraggedColumn");
                    n.parent().addClass("WWPDraggingColumn");
                    var f;
                    f = n.hasClass("FixedColumnL") ? ">th.FixedColumnL:not(.DisableColMoving,.ConfigFixedColumn)" : n.hasClass("FixedColumnR") ? ">th.FixedColumnR:not(.DisableColMoving,.ConfigFixedColumn)" : ">th:not(.DisableColMoving,.ConfigFixedColumn,.FixedColumnL,.FixedColumnR)";
                    n.parent().find(f).bind("dragover", function(t) {
                        var r, f;
                        i != null && i.removeClass("WWPDragOverUp WWPDragOverDown");
                        i = $(t.currentTarget);
                        r = i.index();
                        u != r && (f = u > r, i.addClass("WWPDragOver" + (f ? "Up" : "Down")), t.preventDefault());
                        requestAnimationFrame(function() {
                            n.parent().addClass("WWPDraggingColumnMoving")
                        })
                    }).bind("drop", function() {
                        var c, f, r, u, h, e, o, s;
                        if (t.ColumnSelectorHelper.my_dropDownOptions.ColumnsSelectorData_Aux = JSON.parse(JSON.stringify(t.ColumnSelectorHelper.DropDownOptionsData, null, 2)), t.DropDownOptionsData_Columns != null && (t.ColumnSelectorHelper.my_dropDownOptions.ColumnsSelectorData_Aux.Columns = JSON.parse(JSON.stringify(t.DropDownOptionsData_Columns, null, 2))), c = i.hasClass("GridGroupTitle"), c) {
                            for (f = 0, r = n.parent().children().first(); r[0] != n[0];) f += r[0].colSpan != null ? r[0].colSpan : 1, r = r.next();
                            for (u = 0, r = n.parent().children().first(); r[0] != i[0];) u += r[0].colSpan != null ? r[0].colSpan : 1, r = r.next();
                            for (f < u && (u += (i[0].colSpan != null ? i[0].colSpan : 1) - 1), h = n[0].colSpan != null ? n[0].colSpan : 1, e = 0; e < h; e++) o = t.ColumnSelectorHelper.my_dropDownOptions.ColumnsSelectorData_Aux.Columns[n.closest("thead").find(">tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)>th:visible:eq(" + (f + (f < u ? h - e - 1 : e)) + ")").data("colIndex")].O, s = t.ColumnSelectorHelper.my_dropDownOptions.ColumnsSelectorData_Aux.Columns[i.closest("thead").find(">tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)>th:visible:eq(" + u + ")").data("colIndex")].O, t.ColumnSelectorHelper.my_dropDownOptions.updateColumnsSelectorValuesIndexByOrderIndexes(o, s)
                        } else o = t.ColumnSelectorHelper.my_dropDownOptions.ColumnsSelectorData_Aux.Columns[n.data("colIndex")].O, s = t.ColumnSelectorHelper.my_dropDownOptions.ColumnsSelectorData_Aux.Columns[i.data("colIndex")].O, t.ColumnSelectorHelper.my_dropDownOptions.updateColumnsSelectorValuesIndexByOrderIndexes(o, s);
                        t.ColumnSelectorHelper.my_dropDownOptions.updateColumnSelectorDataBeforeGxEvent();
                        t.ColumnSelectorHelper.OnColumnsChanged && t.ColumnSelectorHelper.OnColumnsChanged()
                    });
                    n.bind("dragend", function() {
                        i != null && i.removeClass("WWPDragOverUp WWPDragOverDown");
                        n.removeClass("WWPDraggedColumn").parent().removeClass("WWPDraggingColumn WWPDraggingColumnMoving").find(">th").unbind("dragend dragover drop")
                    })
                })
            })
        }
    };
    this.ReOrderColumn = function(n, t, i) {
        for (var e = -1, f = -1, u = n.find(">thead>tr:last-child()>th"), r = 0; r < u.length; r += 1)
            if (!$(u[r]).is(".DisableColMoving,.EditableGridAuxCol"))
                if (e++, e == i) {
                    if (f = r, $(u[r]).data("colIndex") == t) break
                } else if ($(u[r]).data("colIndex") == t) {
            if (f == -1) break;
            this.ColumnSelectorHelper.TotalizersCalled || typeof SetMinWidthTotalizers != "function" || (this.ColumnSelectorHelper.TotalizersCalled = !0, SetMinWidthTotalizers());
            n.data("colReordered", "T");
            n.find(">tbody>tr,>thead>tr,>tfoot>tr").each(function() {
                $(this).find(">*:eq(" + r + ")").insertBefore($(this).find(">*:eq(" + f + ")"))
            });
            $(u[r + 1]).hasClass("EditableGridAuxCol") && n.find(">tbody>tr,>thead>tr,>tfoot>tr").each(function() {
                $(this).find(">*:eq(" + (r + 1) + ")").insertBefore($(this).find(">*:eq(" + (f + 1) + ")"))
            });
            break
        }
    };
    this.FixColumn = function(n, t) {
        var i = t ? "L" : "R";
        this.ColumnSelectorHelper != null && (this.ColumnSelectorHelper.my_dropDownOptions.ColumnsSelectorData_Aux = JSON.parse(JSON.stringify(this.ColumnSelectorHelper.DropDownOptionsData, null, 2)), this.ColumnSelectorHelper.my_dropDownOptions.ColumnsSelectorData_Aux.Columns[n].F = this.ColumnSelectorHelper.my_dropDownOptions.ColumnsSelectorData_Aux.Columns[n].F == i ? "" : i, this.ColumnSelectorHelper.my_dropDownOptions.updateColumnSelectorDataBeforeGxEvent(), this.ColumnSelectorHelper.OnColumnsChanged && this.ColumnSelectorHelper.OnColumnsChanged())
    };
    this.FreezeColumnsOrHeader = function() {
        var n = WWP_GetGrid(this).find(">table"),
            c = n.closest("div"),
            i, h, r, o, u, s, f, l, e, t;
        if (c.width("auto"), n.length == 1) {
            if (i = n.closest(".gx-grid").parent().closest(".HasGridEmpowerer,.gx-grid").hasClass("GridFixedTitles"), i && n.closest(".gx-grid").addClass("gx-gridGridFixedTitles"), h = n.closest(".gx-grid").parent().closest(".HasGridEmpowerer,.gx-grid").hasClass("GridFixedColumnBorders"), h && n.closest(".gx-grid").addClass("gx-gridGridFixedColumnBorders"), r = wwp.settings.columnsSelector.AllowColumnResizing, r && n.closest(".gx-grid").addClass("gx-gridGridResizableTitles"), o = n.find(">thead>tr>th.FixedColumnR,>thead>tr>th.FixedColumnL").length > 0, i && n.find(">thead>tr.GridGroupTitleRow").length > 0 ? (console.error('WorkWithPlus Error: a grid cannot have "Grouped titles" and "Fixed Titles" at the same time.'), n.closest(".GridFixedTitles").removeClass("GridFixedTitles"), i = !1) : i && n.find(">tbody>tr.DVGroupByRow:eq(0)").length > 0 && (console.warn('WorkWithPlus Error: a grid cannot have "Grouped by" and "Fixed Titles" at the same time.'), n.closest(".GridFixedTitles").removeClass("GridFixedTitles"), i = !1), i || o || r)
                if (n.data("Empowered") == null) {
                    if (n.data("Empowered", ""), u = 0, o && (s = n.find(">thead>tr:last-child()>th.FixedColumnR:visible").first().index(), s != -1 && (u = n.find(">thead>tr:last-child()>th").length - s)), f = null, r && (f = WWPEmpowerGrid_UpdateGrdiColumnsMinWidth(n, i, r)), e = 0, (i || o) && (l = n.attr("id").replace("ContainerTbl", "").toUpperCase(), n.addClass("ColsFixed"), e = n.find(">thead>tr>th.FixedColumnL:visible").last().index() + 1, n.find(">*>tr>*").css("left", ""), n.parent().unbind("scroll"), this.ColumnsOrHeaderFixer = new ColumnsOrHeaderFixer(n, {
                            left: e,
                            right: u,
                            hasFixedTitles: i,
                            hasResizableTitles: r
                        })), t = this, r) n.find(">thead>tr:not(.FGHeaderRowH,.GridGroupTitleRow)>th, >thead>tr.FGHeaderRowV>th>div").unbind("mousemove").on("mousemove", function(i) {
                        var s, c, l, a, v, p;
                        if (i.buttons != 1 && n.find(">thead").removeData("wwpMoving"), s = n.find(">thead").data("wwpMoving"), c = s != null || GetResizedItem(i) != null, $(this).css("cursor", c ? "col-resize" : ""), c ? ($(this).parent().find(">.WWPDraggable").each(function() {
                                this.draggable = !1
                            }), window.getSelection && window.getSelection().focusNode != null && $(window.getSelection().focusNode).closest("ul,tr")[0] == $(this).closest("tr")[0] && (window.getSelection().empty ? window.getSelection().empty() : window.getSelection().removeAllRanges && window.getSelection().removeAllRanges())) : $(this).parent().find(">.WWPDraggable").each(function() {
                                this.draggable = !0
                            }), s != null) {
                            for (var o = n.find(">tbody>tr:not(.DVGroupByRow,.FGRowLine):eq(0)>td:eq(" + s + ")"), r = i.pageX - o.offset().left, h = o.next(); h.css("display") == "none";) h = h.next();
                            if (l = h.length == 0, l && r >= o.outerWidth() - 2 && (r += 10), r > 20 && r > o.width() && e + u > 0) {
                                var y = e > 0 ? n.find(">thead>tr:not(.FGHeaderRowH,.GridGroupTitleRow)>th:eq(" + (e - 1) + ")") : null,
                                    w = e > 0 ? y.offset().left + y.outerWidth() - n.parent().offset().left : 0,
                                    b = u > 0 ? n.find(">thead>tr:not(.FGHeaderRowH,.GridGroupTitleRow)>th:eq(" + (n.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)>th").length - u) + ")") : null,
                                    k = u > 0 ? n.parent().offset().left + n.parent().outerWidth() - b.offset().left : getScrollWidthIfVisible(n.parent(), !0),
                                    d = n.parent().outerWidth() - w - k,
                                    g = o.outerWidth() + d - 20;
                                r > g && (r = 0)
                            }
                            r > 20 && (a = n.find(">tbody>tr:not(.DVGroupByRow,.FGRowLine):eq(0)>td:visible"), a.each(function() {
                                $(this).data("dvMW", $(this).outerWidth())
                            }), a.each(function() {
                                $(this).css({
                                    "min-width": $(this).data("dvMW") + "px"
                                });
                                $(this).removeData("dvMW")
                            }), o.css({
                                "min-width": r + "px"
                            }), f == null && (f = [], n.find(">tbody>tr:not(.DVGroupByRow,.FGRowLine):eq(0)>td").each(function() {
                                f.push(-1)
                            })), typeof SetMinWidthPaginationBar == "function" && SetMinWidthPaginationBar(n[0]), l && n.parent().scrollLeft(n.outerWidth()), t.ColumnsOrHeaderFixer != null && (t.ColumnsOrHeaderFixer.settings.firstNotFixedLeft_addedPadding != null && t.ColumnsOrHeaderFixer.settings.firstNotFixedLeft == o.index() ? (r = r - t.ColumnsOrHeaderFixer.settings.firstNotFixedLeft_addedPadding, t.ColumnsOrHeaderFixer.settings.firstNotFixedLeft_minWidth = r) : t.ColumnsOrHeaderFixer.settings.lastNotFixedRight_minWidth != null && t.ColumnsOrHeaderFixer.settings.lastNotFixedRight == o.index() && (t.ColumnsOrHeaderFixer.settings.lastNotFixedRight_minWidth = r), t.ColumnsOrHeaderFixer.Refresh()), v = n.find(">thead>tr:not(.FGHeaderRowH,.GridGroupTitleRow)>th:eq(" + s + ")").data("origColIndex"), f[v != null ? v : s] = r, p = window.location.pathname.substring(window.location.pathname.lastIndexOf("/") + 1).replace(".aspx", "") + "_" + n.attr("id").replace("ContainerTbl", ""), createCookie(p, WWP_replaceAll(JSON.stringify(f, null, 2), "\n", "")))
                        }
                    }).unbind("mousedown").on("mousedown", function(t) {
                        var i = GetResizedItem(t);
                        if (i != null) {
                            n.find(">thead").data("wwpMoving", i.index());
                            n.find(">thead").unbind("mouseup").on("mouseup", function() {
                                n.find(">thead").unbind("mouseleave").unbind("mouseup").removeData("wwpMoving")
                            });
                            n.find(">thead").unbind("mouseleave").on("mouseleave", function() {
                                n.find(">thead").unbind("mouseleave").unbind("mouseup").removeData("wwpMoving")
                            })
                        }
                    })
                } else this.ColumnsOrHeaderFixer != null && this.InfiniteScrolling != "False" && n.data("IS_ProcessedRecords") != n.find(">tbody").children().length && this.ColumnsOrHeaderFixer.UpdateInfiniteScrollingNewRecords();
            (i || o) && (n.closest(".gx-ct-body").is(".entering, .leaving") ? (t = this, window.setTimeout(function() {
                t.FreezeColumnsOrHeader()
            }, 100)) : n.parent().trigger("scroll"))
        }
    }
}

function WWPEmpowerGrid_UpdateGrdiColumnsMinWidth(n, t, i) {
    var r = null,
        f, u;
    return i && (f = window.location.pathname.substring(window.location.pathname.lastIndexOf("/") + 1).replace(".aspx", "") + "_" + n.attr("id").replace("ContainerTbl", ""), r = readCookie(f), r != null && (r = JSON.parse(r), r.length != n.find(">tbody>tr:not(.DVGroupByRow):eq(0)>td").length && (r = null))), (r != null || t) && (t && (n.find(">thead>tr>th").css({
        "min-width": "0px"
    }), n.find(">tfoot>tr>td").css({
        "min-width": "0px"
    })), u = n.find(">thead>tr:not(.FGHeaderRowH,.GridGroupTitleRow)>th"), n.find(">tbody>tr:not(.DVGroupByRow):eq(0)>td").each(function() {
        var t = -1,
            n, i;
        r != null && (n = $(this).index(), i = u.length > n ? $(u[n]).data("origColIndex") : null, n = i != null ? i : n, r[n] > t && (t = r[n]));
        t != -1 && $(this).css({
            "min-width": t + "px"
        })
    })), r
}

function getScrollBarWidth() {
    var t, n, r, i;
    return scrollWidth == null && (t = document.createElement("p"), t.style.width = "100%", t.style.height = "200px", n = document.createElement("div"), n.style.position = "absolute", n.style.top = "0px", n.style.left = "0px", n.style.visibility = "hidden", n.style.width = "200px", n.style.height = "150px", n.style.overflow = "hidden", n.appendChild(t), document.body.appendChild(n), r = t.offsetWidth, n.style.overflow = "scroll", i = t.offsetWidth, r == i && (i = n.clientWidth), document.body.removeChild(n), scrollWidth = r - i), scrollWidth
}

function GetResizedItem(n) {
    var t, i, r;
    if (n.target != null && (t = n.target.tagName == "TH" ? $(n.target) : $(n.target).closest("th,ul"), t.length == 1 && t[0].tagName == "TH" && t.parent().parent().next().children().length > 0 && (i = n.pageX - t.offset().left, r = 3, i <= r || i >= t.outerWidth() - 4))) {
        if (t.parent().hasClass("FGHeaderRowV"))
            if (n.offsetY < t.closest("thead").find(">tr:not(.FGHeaderRowH,.FGHeaderRowV)").last().height()) {
                if (t.hasClass("FixedR"))
                    for (t = t.prev(); t.css("display") == "none";) t = t.prev()
            } else return null;
        else if (i <= r)
            for (t = t.prev(); t.css("display") == "none";) t = t.prev();
        return t.length == 1 ? t : null
    }
    return null
}

function ColumnsOrHeaderFixer(n, t) {
    function u(n, t) {
        return n == null || n.length != 1 ? !1 : t ? n[0].scrollHeight - n[0].clientHeight > 0 : n[0].scrollWidth - n[0].clientWidth > 0
    }

    function i(n, t) {
        return u(n, t) ? getScrollBarWidth() : 0
    }

    function r(n) {
        n.each(function(n, t) {
            var t = $(t),
                u = $(t).parent(),
                i = t.css("background-color"),
                r;
            i = i == "transparent" || i == "rgba(0, 0, 0, 0)" ? null : i;
            i || (r = u.css("background-color"), i = r == "transparent" || r == "rgba(0, 0, 0, 0)" ? "white" : r);
            t.css("background-color", i)
        })
    }
    this.bindScrollEvent = function() {
        var n = this.settings.$parent,
            r = this.settings.$table,
            t = this;
        if (this.settings.hasFixedTitles) {
            n.data("lastScrollLeft", 0);
            n.data("lastScrollTop", 0);
            n.scroll(function() {
                if (t.settings.$table.find(">thead").data("wwpMoving") != null) t.updateAllRelative();
                else {
                    var u = n.data("lastScrollLeft"),
                        f = n.data("lastScrollTop"),
                        i = n.scrollLeft(),
                        r = n.scrollTop();
                    n.data("lastScrollLeft", i);
                    n.data("lastScrollTop", r);
                    t.propareToScroll(n, u, f, i, r)
                }
            });
            n.unbind("mousewheel mousedown keydown").on("mousewheel mousedown keydown", function(r) {
                var f, u;
                r.type == "mousewheel" && r.originalEvent != null && r.originalEvent.wheelDelta != null ? (u = n.scrollTop(), t.propareToScroll(n, null, u - 1, null, u)) : r.type == "keydown" ? r.keyCode == 37 || r.keyCode == 39 ? (f = n.scrollLeft(), t.propareToScroll(n, f - 1, null, f, null)) : r.keyCode >= 32 && r.keyCode <= 40 && (u = n.scrollTop(), t.propareToScroll(n, null, u - 1, null, u)) : r.type == "mousedown" && $(event.target).hasClass("gx-grid") && (event.offsetY >= n.outerHeight() - i(n, !1) ? (f = n.scrollLeft(), t.propareToScroll(n, f - 1, null, f, null)) : event.offsetX >= n.outerWidth() - i(n, !0) && (u = n.scrollTop(), t.propareToScroll(n, null, u - 1, null, u)))
            })
        }
    };
    this.propareToScroll = function(n, t, i, r, u) {
        this.settings.myT != null && clearInterval(this.settings.myT);
        r = r != null ? r : n.scrollLeft();
        u = u != null ? u : n.scrollTop();
        t = t != null ? t : r;
        i = i != null ? i : u;
        t != r ? n.data("isScrollingH") == null && (n.data("isScrollingV", null), n.data("isScrollingH", "T"), this.updateAllRelative(), this.updateFrozenColumnsAbsolute()) : i != u && n.data("isScrollingV") == null && this.settings.hasFixedTitles && (n.data("isScrollingH", null), n.data("isScrollingV", "T"), this.updateAllRelative(), this.updateTitlesAbsolute());
        r != n.scrollLeft() && n.scrollLeft(r);
        u != n.scrollTop() && n.scrollTop(u);
        var f = this;
        this.settings.myT = setInterval(function() {
            clearInterval(f.settings.myT);
            f.unprepareScroll(n)
        }, 300)
    };
    this.unprepareScroll = function(n) {
        if (this.settings.unprepare) {
            var t = n.scrollLeft(),
                i = n.scrollTop();
            n.data("isScrollingV", null);
            n.data("isScrollingH", null);
            this.updateAllRelative();
            t != n.scrollLeft() && n.scrollLeft(t);
            i != n.scrollTop() && n.scrollTop(i)
        }
    };
    this.updateAllRelative = function() {
        var r, u, f, h, c, t;
        WWP_Debug_Log(!1, "updateAllRelative");
        var o = this.settings.$parent,
            n = this.settings.$table,
            e = o.scrollLeft(),
            s = o.scrollTop();
        for (this.settings.left > 0 && (n.find(">tbody>tr:not(.FGRowLine)>td:nth-child(" + (this.settings.firstNotFixedLeft + 1) + "), >thead>tr:not(.FGHeaderRowH,.GridGroupTitleRow)>th:nth-child(" + (this.settings.firstNotFixedLeft + 1) + "), >tfoot>tr:not(.FGFootRow)>td:nth-child(" + (this.settings.firstNotFixedLeft + 1) + ")").css({
                "padding-left": ""
            }), this.settings.hasGroupTitles && n.find(">thead>tr.GridGroupTitleRow>th[mColIndex=" + this.settings.firstNotFixedLeft + "]").css({
                "padding-left": ""
            }), this.settings.firstNotFixedLeft_minWidth != null && (n.find(this.settings.S_RowCells + ":nth-child(" + (this.settings.firstNotFixedLeft + 1) + "):eq(0)").css({
                "min-width": this.settings.firstNotFixedLeft_minWidth
            }), this.settings.firstNotFixedLeft_minWidth = null, this.settings.firstNotFixedLeft_addedPadding = null)), this.settings.hasRowGroups && this.settings.left + this.settings.right > 0 && n.find(">tbody>tr.DVGroupByRow>td").css({
                "padding-top": ""
            }), this.settings.right > 0 && this.settings.lastNotFixedRight_minWidth != null && (n.find(this.settings.S_RowCells + ":nth-child(" + (this.settings.lastNotFixedRight + 1) + "):eq(0)").css({
                "min-width": this.settings.lastNotFixedRight_minWidth
            }), this.settings.lastNotFixedRight_minWidth = null), n.find(this.settings.S_Rows).css("height", ""), n.find(">thead>tr:not(.FGHeaderRowH)>th, >tfoot>tr:not(.FGFootRow)>td").css("width", ""), this.updateFixedTitlesRelative(s), n.find(">thead>tr:not(.FGHeaderRowH)>th,>tfoot>tr:not(.FGFootRow)>td").css({
                left: "",
                visibility: "",
                right: "",
                "padding-top": ""
            }), this.settings.left > 0 && this.settings.leftColumns.css({
                left: e,
                position: "relative"
            }), r = 0; r < this.settings.left; r++) n.find(this.settings.S_RowCells + ":nth-child(" + (r + 1) + ")").css({
            top: "",
            visibility: "",
            "padding-top": ""
        }).removeClass("FGCuttedCell");
        for (r = this.settings.firstRightColumn; r < this.settings.totalColumns; r++) n.find(this.settings.S_RowCells + ":nth-child(" + (r + 1) + ")").css({
            top: "",
            visibility: "",
            "padding-top": ""
        }).removeClass("FGCuttedCell");
        if (this.hasRowGroupsWithTot && n.find(">tbody>tr.DVGroupByRow>td[titleCell]").css("position", "absolute"), u = null, t = null, (this.settings.right > 0 || this.settings.hasRowGroups) && (u = n.outerWidth(), t = u - this.tableAvailableWidthForGrid() - e, t < 0 && (t = 0)), this.settings.right > 0 && (this.settings.rightColumns.css({
                right: t,
                position: "relative",
                left: ""
            }), n.find(">tbody>tr:not(.FGRowLine)>td:nth-child(" + (this.settings.lastNotFixedRight + 1) + "), >thead>tr:not(.FGHeaderRowH,.GridGroupTitleRow)>th:nth-child(" + (this.settings.lastNotFixedRight + 1) + "), >tfoot>tr:not(.FGFootRow)>td:nth-child(" + (this.settings.lastNotFixedRight + 1) + ")").css({
                "padding-right": ""
            }), this.settings.hasGroupTitles && n.find(">thead>tr.GridGroupTitleRow>th[mColIndex=" + this.settings.lastNotFixedRight + "]").css({
                "padding-right": ""
            }).length == 0)) {
            for (f = this.settings.lastNotFixedRight - 1; f >= 0 && n.find(">thead>tr.GridGroupTitleRow>th[mColIndex=" + f + "]").length == 0;) f--;
            n.find(">thead>tr.GridGroupTitleRow>th[mColIndex=" + f + "]").css({
                "padding-right": ""
            })
        }
        this.settings.hasVerticalBorders && (h = n.parent().outerHeight() - i(n.parent(), !1) - parseInt(n.css("margin-top")) - parseInt(n.parent().css("border-bottom-width")) - parseInt(n.parent().css("border-top-width")) - 1, c = n.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)").last().outerHeight() * -1, this.updateVerticalBordersCss(c, h));
        this.settings.hasRowGroups && n.find(">tbody>tr.DVGroupByRow>td[titleCell]").css({
            "padding-left": e,
            "padding-right": this.DVGroupByRowOriginalPaddingR != null ? t + this.DVGroupByRowOriginalPaddingR : ""
        });
        this.updateFixedTitlesRelative(s);
        u != null && u != this.settings.$table.outerWidth() && (u = n.outerWidth(), t = u - this.tableAvailableWidthForGrid() - e, t < 0 && (t = 0), this.settings.rightColumns.css({
            right: t
        }))
    };
    this.updateVerticalBordersCss = function(n, t) {
        var i = this.settings.$table,
            r;
        this.settings.hasGroupTitles ? (r = i.find(">thead>tr.GridGroupTitleRow").outerHeight(), i.find(">thead>tr.FGHeaderRowV>th>div").each(function() {
            var f, u;
            if ($(this).parent().hasClass("FixedR")) f = $(this).parent().index();
            else {
                for (u = $(this).parent().next(); u.length == 1 && !u.is(":visible");) u = u.next();
                f = u.index()
            }
            i.find(">thead>tr.GridGroupTitleRow>th[mColIndex=" + f + "]").length > 0 ? n != null ? $(this).css({
                top: n - r,
                height: t
            }) : $(this).css({
                height: t
            }) : n != null ? $(this).css({
                top: n,
                height: t - r
            }) : $(this).css({
                height: t - r
            })
        })) : n != null ? i.find(">thead>tr.FGHeaderRowV>th>div").css({
            top: n,
            height: t
        }) : i.find(">thead>tr.FGHeaderRowV>th>div").css({
            height: t
        })
    };
    this.updateFixedTitlesRelative = function(n) {
        var f = this.settings.$parent,
            t = this.settings.$table,
            r, u;
        t.find(">thead>tr>th").css({
            top: this.settings.hasFixedTitles ? n : "",
            position: "relative"
        }).removeClass("FGCuttedCell");
        this.settings.footer && (r = "", this.settings.hasFixedTitles && (u = t.find(">tfoot>tr:not(.FGFootRow)"), r = n + f.outerHeight() - parseInt(t.css("border-bottom-width")) - parseInt(t.parent().css("border-top-width")) - parseInt(t.parent().css("border-bottom-width")) - u.outerHeight() - (u.offset().top - t.offset().top) - i(f, !1), r > 0 && (r = 0)), t.find(">tfoot>tr>td").css({
            top: r,
            position: "relative"
        }).removeClass("FGCuttedCell"))
    };
    this.updateTitlesAbsolute = function() {
        var n = this.settings.$table,
            w = n.parent().scrollLeft(),
            c = n.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV)>th:visible").first(),
            y = c.css("position"),
            u = c.css({
                position: "absolute",
                left: ""
            }).css("left"),
            e, s, o, t, h, p, a;
        u = u == "auto" ? c.position().left : parseInt(u);
        c.css({
            position: y
        });
        var v = this.tableAvailableWidthForGrid(),
            l = v + u,
            r = [],
            f = [];
        for (t = 0; t < this.settings.totalColumns; t++) e = n.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV)>th:eq(" + t + ")"), t < this.settings.left ? r.push(t > 0 ? r[t - 1] + f[t - 1] : u) : t >= this.settings.firstRightColumn ? r.push(0) : r.push(e.position().left), f.push(e.is(":visible") ? e.outerWidth() : 0), e.find(">*").length > 0 && (o = e.find(">*:eq(0)").offset().top - e.offset().top, o > 0 && e.css("padding-top", o)), this.settings.foot && (s = n.find(">tfoot>tr:not(.FGFootRow)>td:eq(" + t + ")"), s.find(">*").length > 0 && (o = s.find(">*:eq(0)").offset().top - s.offset().top, o > 0 && s.css("padding-top", o)));
        for (t = this.settings.totalColumns - 1; t >= this.settings.firstRightColumn; t--) r[t] = (t == this.settings.totalColumns - 1 ? l : r[t + 1]) - f[t];
        n.find(this.settings.S_Rows + ":eq(0)>td").each(function() {
            $(this).css("min-width", f[$(this).index()])
        });
        h = n.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV)>th:visible").first().outerHeight();
        p = parseInt(n.css("margin-top")) + parseInt(n.parent().css("border-top-width"));
        n.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV)>th").css({
            top: "",
            position: "absolute",
            height: h
        });
        n.find(">thead>tr.FGHeaderRowV>th").css({
            top: "",
            position: "absolute"
        });
        n.find(">thead>tr.FGHeaderRowH>th").css({
            top: "",
            position: "absolute",
            height: n.find(">thead>tr.FGHeaderRowH>th:eq(0)").outerHeight(),
            width: v
        });
        n.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV)").css({
            height: h
        });
        h = n.find(">tfoot>tr:not(.FGFootRow)>td:visible").first().outerHeight();
        a = n.parent().outerHeight() - n.find(">tfoot>tr:not(.FGFootRow)").outerHeight() - i(n.parent(), !1) - parseInt(n.parent().css("border-bottom-width"));
        n.find(">tfoot>tr:not(.FGFootRow)>td").css({
            top: a,
            position: "absolute",
            height: h
        });
        n.find(">tfoot>tr.FGFootRow>td").css({
            top: a - parseInt(n.find(">tfoot>tr.FGFootRow").css("height")),
            position: "absolute",
            height: n.find(">tfoot>tr.FGFootRow").height(),
            width: n.parent().outerWidth() - i(n.parent(), !0)
        });
        n.find(">thead>tr:not(.FGHeaderRowH)>th, >tfoot>tr:not(.FGFootRow)>td").each(function() {
            r[$(this).index()] > l || r[$(this).index()] + f[$(this).index()] < u ? $(this).css({
                visibility: "hidden",
                left: -1e3
            }) : r[$(this).index()] + f[$(this).index()] > l ? ($(this).css({
                width: l - r[$(this).index()],
                left: r[$(this).index()],
                visibility: ""
            }), $(this).parent().hasClass("FGHeaderRowV") || $(this).addClass("FGCuttedCell")) : r[$(this).index()] < u ? ($(this).css({
                width: f[$(this).index()] - (u - r[$(this).index()]),
                left: u,
                visibility: ""
            }), $(this).parent().hasClass("FGHeaderRowV") || $(this).addClass("FGCuttedCell")) : $(this).css({
                width: f[$(this).index()],
                left: r[$(this).index()],
                visibility: ""
            })
        })
    };
    this.tableAvailableWidthForGrid = function() {
        return this.settings.$parent.outerWidth() - (this.settings.hasFixedTitles ? i(this.settings.$parent, !0) : 0) - parseInt(this.settings.$parent.css("border-left-width")) - parseInt(this.settings.$parent.css("border-right-width"))
    };
    this.tableAvailableHeightForGrid = function() {
        return this.settings.$parent.outerHeight() - i(this.settings.$parent, !1) - parseInt(this.settings.$parent.css("border-top-width")) - parseInt(this.settings.$parent.css("border-bottom-width"))
    };
    this.updateFrozenColumnsAbsolute = function() {
        var f, u, o, e, tt, p, w;
        if (this.settings.left + this.settings.right != 0) {
            WWP_Debug_Log(!1, "updateFrozenColumnsAbsolute");
            var t = this.settings.$table,
                v = t.parent().scrollTop(),
                s = [],
                i = [],
                y = [],
                d = [],
                g = 0,
                nt = 0;
            for (f = 0; f < this.settings.left; f++) u = t.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)>th:eq(" + f + ")"), s.push(u.position().left), i.push(u.outerWidth()), u.find(">*").length > 0 && (e = u.find(">*:eq(0)").offset().top - u.offset().top, e > 0 && u.css("padding-top", e)), t.find(this.settings.S_RowCells + ":eq(" + f + ")").css("display") != "none" && (g += i[f]), o = t.find(">thead>tr.GridGroupTitleRow>th:eq(" + f + ")"), o.length > 0 && o.find(">*").length > 0 && (e = o.find(">*:eq(0)").offset().top - o.offset().top, e > 0 && o.css("padding-top", e));
            for (f = this.settings.firstRightColumn; f < this.settings.totalColumns; f++) u = t.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)>th:eq(" + f + ")"), s.push(u.position().left), i.push(u.outerWidth()), u.find(">*").length > 0 && (e = u.find(">*:eq(0)").offset().top - u.offset().top, e > 0 && u.css("padding-top", e)), t.find(this.settings.S_RowCells + ":eq(" + f + ")").css("display") != "none" && (nt += i[i.length - 1]), o = t.find(">thead>tr.GridGroupTitleRow>th:eq(" + f + ")"), o.length > 0 && o.find(">*").length > 0 && (e = o.find(">*:eq(0)").offset().top - o.offset().top, e > 0 && o.css("padding-top", e));
            for (tt = t.find(">tbody>tr:not(.FGRowLine)").length, p = 0; p < tt; p++) w = t.find(">tbody>tr:not(.FGRowLine):eq(" + p + ")"), y.push(w.outerHeight()), d.push(w.position().top - v + parseInt(t.parent().css("border-top-width"))), w.css("height", y[y.length - 1]);
            var k = t.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)").outerHeight(),
                rt = t.find(">tfoot>tr:not(.FGFootRow)").outerHeight(),
                h = parseInt(t.css("margin-top")) + parseInt(t.parent().css("border-top-width")),
                b = h + this.tableAvailableHeightForGrid(),
                ut = b - t.find(">tfoot>tr:not(.FGFootRow)").outerHeight(),
                n = this;
            if (t.find(">tbody>tr:not(.FGRowLine)>td").each(function() {
                    var t = $(this),
                        i = t.index(),
                        r;
                    (i < n.settings.left || i >= n.settings.firstRightColumn) && (i >= n.settings.firstRightColumn && (i = i - (n.settings.firstRightColumn - n.settings.left)), t.find(">*").length > 0 && (r = t.find(">*:eq(0)").offset().top - t.offset().top, r > 0 && t.css("padding-top", r)))
                }), !this.settings.initializing) {
                var it = this.settings.hasRowGroups ? this.tableAvailableWidthForGrid() : null,
                    l = null,
                    a = null,
                    c = this.settings.hasFixedTitles;
                t.find(">tbody>tr:not(.FGRowLine)>td, >thead>tr:not(.FGHeaderRowH,.GridGroupTitleRow)>th, >tfoot>tr:not(.FGFootRow)>td").each(function() {
                    var u = $(this),
                        f = u.index(),
                        g, o, p, nt, tt, e, w, ft;
                    if (f < n.settings.left || f >= n.settings.firstRightColumn || n.settings.left == 0 && u.is("[titleCell]"))
                        if (f >= n.settings.firstRightColumn && (f = f - (n.settings.firstRightColumn - n.settings.left)), g = u.parent().index() / 2, u.parent().parent()[0].tagName == "TBODY")
                            if (o = d[g], p = y[g], n.settings.hasRowGroups && u.parent().hasClass("DVGroupByRow"))
                                if (r(u), u.is("[titleCell]") && u.attr("colspan") != n.settings.totalColumnsVisibles) {
                                    if (l == null) {
                                        for (l = it, e = n.settings.firstRightColumn; e < n.settings.totalColumns; e++) w = t.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)>th:eq(" + e + ")"), w.is(":visible") && (l -= i[e - (n.settings.firstRightColumn - n.settings.left)]);
                                        if (t.data("groupNoNotFixedTot") != null) a = l - (n.settings.hasVerticalBorders ? 1 : 0);
                                        else if (n.settings.left > 0) {
                                            for (a = 0, e = 0; e < n.settings.left; e++) w = t.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)>th:eq(" + e + ")"), w.is(":visible") && (a += i[e]);
                                            n.settings.hasVerticalBorders && a--
                                        }
                                    }
                                    u.css({
                                        "padding-left": "",
                                        "padding-right": "",
                                        position: "absolute",
                                        left: s[f],
                                        "max-width": l,
                                        "min-width": a,
                                        top: "inherit",
                                        height: p - (n.settings.isIE ? 1 : 0) + "px",
                                        "z-index": n.settings.zIndex + 3
                                    })
                                } else nt = u.is("[titleCell]") ? it : i[f], tt = u.is("[titleCell]") ? n.settings.zIndex + 3 : u.index() >= n.settings.firstRightColumn ? n.settings.zIndex : "", u.css({
                                    "padding-left": "",
                                    "padding-right": "",
                                    position: "absolute",
                                    left: s[f],
                                    width: nt,
                                    top: "inherit",
                                    height: p - (n.settings.isIE ? 1 : 0) + "px",
                                    "z-index": tt
                                });
                    else o > b || o + p < h ? u.css({
                        visibility: "hidden",
                        position: "absolute",
                        top: c ? -1e3 : "",
                        left: -1e3
                    }) : o + p > b + 1 ? (u.css({
                        "padding-top": "",
                        visibility: "",
                        position: "absolute",
                        right: "",
                        left: s[f],
                        width: i[f],
                        top: c ? o + (n.settings.isIE ? 1 : 0) : "",
                        height: b - o - (n.settings.isIE ? 1 : 0) + "px"
                    }), u.addClass("FGCuttedCell")) : o < h ? (u.css({
                        visibility: "",
                        position: "absolute",
                        right: "",
                        left: s[f],
                        width: i[f],
                        top: c ? h : "",
                        height: p - (h - o) + "px"
                    }), u.addClass("FGCuttedCell")) : (u.css({
                        visibility: "",
                        position: "absolute",
                        right: "",
                        left: s[f],
                        width: i[f],
                        top: "",
                        height: p - (n.settings.isIE ? 1 : 0) + "px"
                    }), c && v > 0 && (ft = u.css("top"), ft == "auto" ? u.css({
                        top: u.position().top - v
                    }) : u.css({
                        top: parseInt(u.css("top")) - v
                    })));
                    else u[0].tagName == "TH" ? u.parent().hasClass("FGHeaderRowV") ? u.css({
                        position: "absolute",
                        left: s[f],
                        width: i[f],
                        top: ""
                    }) : u.css({
                        position: "absolute",
                        left: s[f],
                        width: i[f],
                        top: "",
                        height: k + "px"
                    }) : u.css({
                        position: "absolute",
                        left: s[f],
                        width: i[f],
                        top: c ? ut : "",
                        height: rt - 1 + "px"
                    })
                });
                this.settings.hasGroupTitles && (k = t.find(">thead>tr.GridGroupTitleRow").outerHeight(), t.find(">thead>tr.GridGroupTitleRow>th").each(function() {
                    var f = $(this),
                        t = parseInt(f.attr("mColIndex")),
                        u, e, r;
                    if (t < n.settings.left || t >= n.settings.firstRightColumn) {
                        for (t >= n.settings.firstRightColumn && (t = t - (n.settings.firstRightColumn - n.settings.left)), u = i[t], e = this.colSpan, r = 1; r < e; r++) u += i[t + r];
                        f.css({
                            position: "absolute",
                            left: s[t],
                            width: u,
                            top: c ? h : "",
                            height: k + "px"
                        })
                    }
                }))
            }
            this.settings.left > 0 && this.appendPaddingToFirstNotFixed(t, !0, this.settings.firstNotFixedLeft, g);
            this.settings.right > 0 && this.appendPaddingToFirstNotFixed(t, !1, this.settings.lastNotFixedRight, nt);
            this.settings.left > 0 || this.settings.right > 0
        }
    };
    this.appendPaddingToFirstNotFixed = function(n, t, i, r) {
        var u = t ? "left" : "right",
            f, o, e;
        if (i++, n.find(this.settings.S_RowCells + ":nth-child(" + i + ")").css("padding-" + u, r + parseInt(n.find(this.settings.S_RowCells + ":nth-child(" + i + "):eq(0)").css("padding-" + u)) + "px"), n.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)>th:nth-child(" + i + ")").css("padding-" + u, r + parseInt(n.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)>th:nth-child(" + i + "):eq(0)").css("padding-" + u)) + "px"), n.find(">tfoot>tr:not(.FGFootRow)>td:nth-child(" + i + ")").css("padding-" + u, r + parseInt(n.find(">tfoot>tr:not(.FGFootRow)>td:nth-child(" + i + "):eq(0)").css("padding-" + u)) + "px"), this.settings.hasGroupTitles && (n.find(">thead>tr.GridGroupTitleRow>th[mColIndex=" + (i - 1) + "]").css("padding-" + u, r + parseInt(n.find(">thead>tr.GridGroupTitleRow>th[mColIndex=" + (i - 1) + "]:eq(0)").css("padding-" + u)) + "px"), !t && n.find(">thead>tr.GridGroupTitleRow>th[mColIndex=" + (i - 1) + "]").length == 0)) {
            for (f = i - 2; f >= 0 && n.find(">thead>tr.GridGroupTitleRow>th[mColIndex=" + f + "]").length == 0;) f--;
            n.find(">thead>tr.GridGroupTitleRow>th[mColIndex=" + f + "]").css("padding-" + u, r + parseInt(n.find(">thead>tr.GridGroupTitleRow>th[mColIndex=" + f + "]:eq(0)").css("padding-" + u)) + "px")
        }
        this.settings.hasRowGroups && n.find(">tbody>tr.DVGroupByRow:eq(0)>td[totCol]:nth-child(" + i + ")").length > 0 && (o = parseInt(this.settings.$table.find(">tbody>tr.DVGroupByRow:eq(0)>td[totCol]:nth-child(" + i + ")").css("padding-" + u)), n.find(">tbody>tr.DVGroupByRow>td:nth-child(" + i + ")").css("padding-" + u, o + r));
        e = n.find(this.settings.S_RowCells + ":nth-child(" + i + "):eq(0)").css("min-width");
        n.find(this.settings.S_RowCells + ":nth-child(" + i + "):eq(0)").css({
            "min-width": r + parseInt(e) + "px"
        });
        t ? (this.settings.firstNotFixedLeft_minWidth = e, this.settings.firstNotFixedLeft_addedPadding = r) : (this.settings.left == 0 || this.settings.firstNotFixedLeft != this.settings.lastNotFixedRight) && (this.settings.lastNotFixedRight_minWidth = e)
    };
    this.geVisibleColumns = function() {
        var n = "";
        return this.settings.$table.find("tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)>th*").each(function() {
            n != "" && (n += ";");
            n += $(this).css("display") != "none" ? "1" : "0"
        }), n
    };
    this.undoAllModifications = function() {
        this.preparedAndFixed && (this.preparedAndFixed = !1, this.settings.$table.find(">thead>tr.FGHeaderRowV,>thead>tr.FGHeaderRowH,>tbody>tr.FGRowLine,>tfoot>tr.FGFootRow").remove(), this.settings.$table.find(this.settings.S_Rows).css("height", ""), this.settings.$table.find(">thead>tr>th,>tfoot>tr>td,>tbody>tr>td").css({
            left: "",
            position: "",
            "padding-left": "",
            top: "",
            visibility: "",
            "padding-top": "",
            "min-width": "",
            "max-width": "",
            right: "",
            "padding-right": "",
            width: "",
            height: "",
            "background-color": ""
        }).removeClass("FGCuttedCell"), this.settings.$table.css("border-style", "").removeClass("FTBRemoveBorders"), this.settings.$parent.unbind("scroll mousewheel mousedown keydown"))
    };
    this.prepareAndFix = function() {
        var n = this.settings.$table,
            t, w, i, e, o, f, s, h, v, l, y, p, c, u, a;
        if (this.settings.left + this.settings.right > 0 && this.gridWidthOverlapped > 0 && this.gridWidthOverlapped >= this.tableAvailableWidthForGrid() && (this.settings.left = 0, this.settings.right = 0), this.visibleColumns = this.geVisibleColumns(), this.settings.hasFixedTitles || this.settings.left + this.settings.right > 0) {
            if (this.settings.$parent.css("overflow-x", "auto"), this.settings.$parent.css("overflow-y", this.settings.hasFixedTitles ? "auto" : "hidden"), this.preparedAndFixed = !0, t = this, this.settings.left > 0 && (this.settings.leftColumns = $(), w = n.find(">thead>tr, " + this.settings.S_Rows + ", >tfoot>tr"), w.each(function(n, i) {
                    t.solverLeftColspan(i, function(n) {
                        t.settings.leftColumns = t.settings.leftColumns.add(n)
                    })
                }), this.settings.leftColumns.each(function(n, i) {
                    var i = $(i);
                    r(i);
                    i.css({
                        position: "relative",
                        "z-index": t.settings.zIndex + (i[0].tagName == "TH" ? 2 : i.parent().parent()[0].tagName == "TFOOT" ? 1 : 0)
                    })
                })), this.settings.right > 0 && (this.settings.rightColumns = $(), n.find(">thead>tr, " + this.settings.S_Rows + ", >tfoot>tr").each(function(n, i) {
                    t.solveRightColspan(i, function(n) {
                        t.settings.rightColumns = t.settings.rightColumns.add(n)
                    })
                }), this.settings.rightColumns.each(function(n, i) {
                    var i = $(i);
                    r(i);
                    i.css({
                        position: "relative",
                        "z-index": t.settings.zIndex + (i[0].tagName == "TH" ? 2 : i.parent().parent()[0].tagName == "TFOOT" ? 1 : 0)
                    })
                })), this.settings.hasFixedTitles && (n.find(">thead>tr>th").each(function(n, i) {
                    i = $(i);
                    var u = i.index();
                    u >= t.settings.left && u < t.settings.firstRightColumn && (r(i), i.css("z-index", t.settings.zIndex))
                }), n.find(">tfoot>tr>td").each(function(n, i) {
                    i = $(i);
                    var u = i.index();
                    u >= t.settings.left && u < t.settings.firstRightColumn && (r(i), i.css("z-index", t.settings.zIndex - 1))
                })), this.settings.hasFixedTitles || this.settings.left + this.settings.right > 0) {
                if (n.css("border-style", "none"), i = this.gridHeaderLineCell(), i.length == 0) {
                    if (e = n.find(">thead>tr:last-child()"), o = e.find(">*:visible").length, this.settings.hasVerticalBorders = n.closest(".gx-grid").parent().closest(".HasGridEmpowerer,.gx-grid").hasClass("GridFixedColumnBorders"), this.settings.hasVerticalBorders) {
                        for (u = document.createElement("tr"), u.className = "FGHeaderRowV", $(u).css("height", "0"), f = 0; f < this.settings.totalColumns; f++) i = document.createElement("th"), s = n.find(">thead>tr:not(.FGHeaderRowH)").last().find(">th:eq(" + f + ")"), h = s.css("display"), h == "none" && s[0].style.display != "none" && s.hasClass("hidden-xs") && (h = ""), h != "none" ? (s.hasClass("hidden-xs") && $(i).addClass("hidden-xs"), $(i).css({
                            "z-index": this.settings.zIndex + (f < this.settings.left || f >= this.settings.firstRightColumn ? 2 : 0)
                        }), v = document.createElement("div"), this.settings.lastNotFixedRight == f && $(v).css("visibility", "hidden"), $(i).append(v)) : $(i).css("display", h), $(u).append(i), f < this.settings.left ? this.settings.leftColumns = this.settings.leftColumns.add($(i)) : f >= this.settings.firstRightColumn && (this.settings.rightColumns = this.settings.rightColumns.add($(i)), $(i).addClass("FixedR"));
                        n.find(">thead").append(u)
                    }
                    parseFloat(e.css("border-bottom-width")) > 0 && (u = document.createElement("tr"), u.className = "FGHeaderRowH", $(u).css("height", e.css("border-bottom-width")), i = document.createElement("th"), i.colSpan = o, $(i).css({
                        "background-color": e.css("border-bottom-color"),
                        "z-index": this.settings.zIndex + 2
                    }), $(u).append(i), n.find(">thead").append(u));
                    l = n.find(this.settings.S_Rows + ":eq(0)");
                    parseFloat(l.css("border-top-width")) > 0 && (y = l.css("border-top-width"), p = l.css("border-top-color"), this.settings.isIE ? ($('<tr class="FGRowLine"><td colSpan="' + o + '"><div><\/div><\/td><\/tr>').insertAfter(n.find(">tbody>tr")), n.find(">tbody>tr.FGRowLine>td>div").css("border-top", "solid " + y + " " + p)) : ($('<tr class="FGRowLine"><td colSpan="' + o + '"><\/td><\/tr>').insertAfter(n.find(">tbody>tr")), n.find(">tbody>tr.FGRowLine").css("height", y), n.find(">tbody>tr.FGRowLine>td").css("background-color", p)), n.find(">tbody>tr.FGRowLine:last-child()").remove());
                    this.settings.footer && (c = n.find(">tfoot>tr"), parseFloat(c.css("border-top-width")) > 0 && (u = document.createElement("tr"), u.className = "FGFootRow", $(u).css("height", c.css("border-top-width")), a = document.createElement("td"), a.colSpan = o, $(a).css({
                        "background-color": c.css("border-top-color"),
                        "z-index": this.settings.zIndex + 2
                    }), $(u).append(a), $(u).insertBefore(c)))
                }
                n.addClass("FTBRemoveBorders")
            }
            this.updateAllRelative();
            this.settings.hasFixedTitles || this.updateFrozenColumnsAbsolute()
        } else this.settings.$parent.css("overflow", ""), this.settings.$parent.css("overflow-y", "");
        this.bindScrollEvent()
    };
    this.gridHeaderLineCell = function() {
        return this.settings.$table.find(">thead>tr.FGHeaderRowH>th")
    };
    this.solverLeftColspan = function(n, t) {
        var i, r;
        if ($(n).hasClass("GridGroupTitleRow"))
            for (i = 0; i < this.settings.left; i++) $(n.childNodes[i]).attr("mColIndex") <= i && t($(n.childNodes[i]));
        else
            for (i = 1; i <= this.settings.left; i++) r = $(n).find("> *:nth-child(" + i + ")"), t(r)
    };
    this.solveRightColspan = function(n, t) {
        var i, r;
        if ($(n).hasClass("GridGroupTitleRow"))
            for (i = 0; i < n.childNodes.length; i++) $(n.childNodes[i]).attr("mColIndex") >= this.settings.firstRightColumn && t($(n.childNodes[i]));
        else
            for (i = 1; i <= this.settings.right; i++) r = $(n).find("> *:nth-child(" + (this.settings.firstRightColumn + i) + ")"), t(r)
    };
    this.UpdateInfiniteScrollingNewRecords = function() {
        this.visibleColumns = null;
        this.Refresh()
    };
    this.WCD_PrepareToExpand = function(n) {
        var f, o, r;
        if (this.settings.hasVerticalBorders) {
            var t = this.settings.$table,
                e = $(n).position().top + $(n).outerHeight(),
                u = t.find(">tbody>tr.WCD_tr");
            u.length == 1 && u.index() < $(n).index() && (e -= u.outerHeight());
            this.updateVerticalBordersCss(null, e);
            f = t.parent().outerHeight() - i(t.parent(), !1) - parseInt(t.css("margin-top")) - parseInt(t.parent().css("border-bottom-width")) - parseInt(t.parent().css("border-top-width")) - 1;
            f -= e;
            u.length == 1 && (f -= u.outerHeight());
            t.find(">tbody>tr.FGHeaderRowV").remove();
            f > 0 && (o = t.find(">thead>tr.FGHeaderRowV"), r = document.createElement("tr"), r.className = "FGHeaderRowV", $(r).css("height", "0"), r.innerHTML = WWP_replaceAll(WWP_replaceAll(o[0].innerHTML, "<th", "<td"), "<\/th", "<\/td"), $(r).find(">td>div").css({
                top: "",
                height: f
            }), n.parentNode.insertBefore(r, n.nextSibling))
        }
    };
    this.WCD_Collapsed = function() {
        if (this.settings.hasVerticalBorders) {
            var n = this.settings.$table,
                t = n.parent().outerHeight() - i(n.parent(), !1) - parseInt(n.css("margin-top")) - parseInt(n.parent().css("border-bottom-width")) - parseInt(n.parent().css("border-top-width")) - 1;
            this.updateVerticalBordersCss(null, t);
            n.find(">tbody>tr.FGHeaderRowV").remove()
        }
    };
    this.Refresh = function() {
        var i, e, r, u;
        WWP_Debug_Log(!1, "refreshing");
        var n = 0,
            t = ">thead>tr:not(.FGHeaderRowH,.GridGroupTitleRow)>th",
            f = this.settings.$table.find(t + ".FixedColumnR:visible").first().index();
        f != -1 && (n = this.settings.$table.find(t).length - f);
        i = this.settings.$table.find(t + ".FixedColumnL:visible").last().index() + 1;
        e = this.settings.origLeft + this.settings.origRight > 0 != i + n > 0 || this.geVisibleColumns() != this.visibleColumns;
        e ? (WWP_Debug_Log(!1, "changed"), r = this.settings.$parent.data("WWP.GridTitlesCategories"), r != null && (this.settings.$table.data("titlesCategories", null), r.mergeTitlesCategoryCells()), u = this.settings.$parent.data("WWP.RowGroupsHelper"), u != null && (this.settings.$table.data("groupProcessed", null), u.mergeGroupRowCellsAndAddTitle()), this.undoAllModifications(), this.gridWidthOverlapped = 0, this.gridWidthNotOverlapped = 99999, this.initializeSettings(this.settings.$table, {
            left: i,
            right: n,
            hasFixedTitles: this.settings.HasFixedTitles,
            hasResizableTitles: this.settings.HasResizableTitles
        }), this.prepareAndFix()) : this.preparedAndFixed && (this.updateAllRelative(), this.settings.hasFixedTitles || this.updateFrozenColumnsAbsolute());
        this.checkIfFixedColumnsExceedWidth()
    };
    this.checkIfFixedColumnsExceedWidth = function() {
        var t, n, i, r, u;
        if (this.settings.origLeft + this.settings.origRight > 0) {
            if (t = !1, n = this.tableAvailableWidthForGrid(), n < this.gridWidthNotOverlapped && (this.gridWidthOverlapped >= n ? t = !0 : (this.preparedAndFixed || (this.initializeSettings(this.settings.$table, {
                    left: this.settings.origLeft,
                    right: this.settings.origRight,
                    hasFixedTitles: this.settings.HasFixedTitles,
                    hasResizableTitles: this.settings.HasResizableTitles
                }), this.prepareAndFix()), WWP_Debug_Log(!1, "calculating"), i = 0, this.settings.left > 0 && (r = this.settings.$table.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)>th:eq(" + (this.settings.left - 1) + ")"), i = r.offset().left + r.outerWidth()), u = this.settings.right > 0 ? this.settings.$table.find(">thead>tr:not(.FGHeaderRowH,.FGHeaderRowV,.GridGroupTitleRow)>th:eq(" + this.settings.firstRightColumn + ")").offset().left : n + this.settings.$table.offset().left, i + 50 >= u && (t = !0))), t) return this.gridWidthOverlapped < n && (this.gridWidthOverlapped = n + getScrollBarWidth(), this.gridWidthNotOverlapped < this.gridWidthOverlapped && (this.gridWidthNotOverlapped = this.gridWidthOverlapped)), WWP_Debug_Log(!1, "overlaped"), this.settings.left + this.settings.right > 0 && (this.undoAllModifications(), this.prepareAndFix()), !0;
            WWP_Debug_Log(!1, "not overlaped");
            this.gridWidthNotOverlapped > n && this.gridWidthNotOverlapped >= this.gridWidthOverlapped && (this.gridWidthNotOverlapped = n);
            this.preparedAndFixed && this.settings.left + this.settings.right == 0 && this.undoAllModifications();
            this.preparedAndFixed || (this.initializeSettings(this.settings.$table, {
                left: this.settings.origLeft,
                right: this.settings.origRight,
                hasFixedTitles: this.settings.hasFixedTitles,
                hasResizableTitles: this.settings.hasResizableTitles
            }), this.prepareAndFix())
        }
        return !1
    };
    this.initializeSettings = function(n, t) {
        var i, r;
        this.settings = $.extend({}, {
            head: !0,
            foot: !0,
            left: 0,
            right: 0,
            zIndex: 2
        }, t);
        this.settings.$table = n;
        this.settings.$parent = this.settings.$table.parent();
        this.settings.totalColumns = this.settings.$table.find(">thead>tr:last-child()>*").length;
        this.settings.firstRightColumn = this.settings.totalColumns - this.settings.right;
        this.settings.firstNotFixedLeft = null;
        this.settings.lastNotFixedRight = null;
        this.settings.footer = this.settings.$table.find(">tfoot>tr>td:eq(0)").length > 0;
        this.settings.isIE = WWP_IsIE();
        this.settings.S_Rows = ">tbody>tr:not(.DVGroupByRow,.FGRowLine)";
        this.settings.S_RowCells = ">tbody>tr:not(.DVGroupByRow,.FGRowLine)>td";
        this.settings.unprepare = !0;
        this.settings.origLeft = this.settings.left;
        this.settings.origRight = this.settings.right;
        this.settings.hasGroupTitles = this.settings.$table.find(">thead>tr.GridGroupTitleRow").length > 0;
        this.settings.hasRowGroups = this.settings.$table.find(">tbody>tr.DVGroupByRow:eq(0)").length > 0;
        this.hasRowGroupsWithTot = this.settings.hasRowGroups && this.settings.$table.find(">tbody>tr.DVGroupByRow>td:visible[totCol]:eq(0)").length > 0;
        this.DVGroupByRowOriginalPaddingR = this.settings.hasRowGroupsWithTot ? parseInt(this.settings.$table.find(">tbody>tr.DVGroupByRow>td[titleCell]:eq(0)").css("padding-right")) : null;
        i = this;
        this.settings.left + this.settings.right > 0 && (r = !1, this.settings.$table.find(">thead>tr>th:visible").each(function() {
            if ((i.settings.left == 0 || $(this).index() > i.settings.left - 1) && (i.settings.right == 0 || $(this).index() < i.settings.firstRightColumn)) return r = !0, !1
        }), r || (this.settings.left = 0, this.settings.right = 0));
        this.settings.totalColumnsVisibles = this.settings.$table.find(">thead>tr:last-child()>*:visible").each(function() {
            var n = $(this).index();
            i.settings.firstNotFixedLeft == null && n >= i.settings.left && (i.settings.firstNotFixedLeft = n);
            n < i.settings.firstRightColumn && (i.settings.lastNotFixedRight = n);
            n < i.settings.left ? $(this).addClass("FixedColumnL") : n >= i.settings.firstRightColumn && $(this).addClass("FixedColumnR")
        }).length
    };
    this.gridWidthOverlapped = 0;
    this.gridWidthNotOverlapped = 99999;
    this.initializeSettings(n, t);
    typeof SetMinWidthTotalizers == "function" && SetMinWidthTotalizers();
    this.prepareAndFix();
    this.checkIfFixedColumnsExceedWidth()
}
var scrollWidth = null;
$(window).one('load', function() {
    WWP_VV([
        ['WWP.GridEmpowerer', '14.2']
    ]);
});